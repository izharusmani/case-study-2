<?php 
/*
Plugin Name: My custom block
Author: Izhar Usmani
Description: Very simple plugin to add custom block in gutunberg
*/

function izhar_gutenberg_block() {
	wp_register_script('custom-block-js', plugins_url( 'build/index.js', __FILE__ ), array( 'wp-blocks', 'wp-i18n', 'wp-element' ));
	
	register_block_type( 'izhar/custom-block', array(
		'editor_script' => 'custom-block-js'
	));
}
add_action( 'init', 'izhar_gutenberg_block' );

function custom_front_style() {
    wp_register_style('block-custom-style', plugins_url('css/front_style.css',__FILE__ ));
    wp_enqueue_style('block-custom-style');
}
add_action( 'wp_enqueue_scripts', 'custom_front_style');

function custom_admin_style() {
	wp_register_style('custom-block-css', plugins_url( 'css/block.css', __FILE__ ));
	wp_enqueue_style('custom-block-css');
}
add_action( 'admin_init', 'custom_admin_style');